const form = document.querySelector("#sort-form");
const numbersInput = document.querySelector("#numbers");
const algorithmInput = document.querySelector("#algorithm");
const orderInput = document.querySelector("#order");
const message = document.querySelector("#message");
const resultsSection = document.querySelector("#results");
const stepsSection = document.querySelector("#steps-section");
const originalResult = document.querySelector("#original-result");
const sortedResult = document.querySelector("#sorted-result");
const comparisonsCount = document.querySelector("#comparisons-count");
const swapsCount = document.querySelector("#swaps-count");
const algorithmName = document.querySelector("#algorithm-name");
const stepsBody = document.querySelector("#steps-body");
const testsBody = document.querySelector("#tests-body");
const testSummary = document.querySelector("#test-summary");

function parseNumbers(text) {
  const trimmed = text.trim();
  if (trimmed === "") {
    return { error: "Digite pelo menos um número antes de ordenar." };
  }

  // Aceita vírgulas e espaços como separadores, mas identifica texto inválido.
  const tokens = trimmed.split(/[,\s]+/);
  const numbers = [];

  for (const token of tokens) {
    if (token === "") continue;
    const value = Number(token);
    if (token === "" || !Number.isFinite(value)) {
      return { error: `O valor "${token}" não é um número válido. Use apenas números separados por vírgulas ou espaços.` };
    }
    numbers.push(value);
  }

  if (numbers.length === 0) {
    return { error: "Digite pelo menos um número antes de ordenar." };
  }
  return { numbers };
}

function formatNumber(number) {
  return Object.is(number, -0) ? "0" : String(number);
}

function formatArray(array) {
  return array.map(formatNumber).join(", ");
}

function renderNumberList(container, values) {
  container.replaceChildren();
  values.forEach((value) => {
    const chip = document.createElement("span");
    chip.className = "number-chip";
    chip.textContent = formatNumber(value);
    container.appendChild(chip);
  });
}

function compareWrong(left, right, order) {
  return order === "asc" ? left > right : left < right;
}

function bubbleSort(input, order) {
  const values = [...input];
  const steps = [];
  let comparisons = 0;
  let swaps = 0;

  for (let end = values.length - 1; end > 0; end--) {
    let changed = false;

    for (let i = 0; i < end; i++) {
      comparisons++;
      const left = values[i];
      const right = values[i + 1];

      if (compareWrong(left, right, order)) {
        values[i] = right;
        values[i + 1] = left;
        swaps++;
        changed = true;
        steps.push({
          comparison: `${formatNumber(left)} e ${formatNumber(right)}`,
          decision: "Troca realizada",
          swapped: true,
          state: [...values]
        });
      } else {
        steps.push({
          comparison: `${formatNumber(left)} e ${formatNumber(right)}`,
          decision: "Mantém a posição",
          swapped: false,
          state: [...values]
        });
      }
    }

    if (!changed) break;
  }

  return { values, steps, comparisons, swaps };
}

function selectionSort(input, order) {
  const values = [...input];
  const steps = [];
  let comparisons = 0;
  let swaps = 0;

  for (let i = 0; i < values.length - 1; i++) {
    let target = i;

    for (let j = i + 1; j < values.length; j++) {
      comparisons++;
      const current = values[j];
      const selected = values[target];
      const shouldSelect = order === "asc" ? current < selected : current > selected;

      if (shouldSelect) target = j;

      steps.push({
        comparison: `${formatNumber(current)} e ${formatNumber(selected)}`,
        decision: shouldSelect
          ? `Novo candidato: ${formatNumber(current)}`
          : `Mantém candidato: ${formatNumber(values[target])}`,
        swapped: false,
        state: [...values]
      });
    }

    if (target !== i) {
      const old = values[i];
      values[i] = values[target];
      values[target] = old;
      swaps++;
      steps.push({
        comparison: `${formatNumber(old)} e ${formatNumber(values[i])}`,
        decision: "Troca de posição realizada",
        swapped: true,
        state: [...values]
      });
    } else {
      steps.push({
        comparison: "Posição atual e candidato",
        decision: "Nenhuma troca necessária",
        swapped: false,
        state: [...values]
      });
    }
  }

  return { values, steps, comparisons, swaps };
}

function renderSteps(steps) {
  stepsBody.replaceChildren();

  if (steps.length === 0) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 4;
    cell.className = "empty-cell";
    cell.textContent = "A sequência tem apenas um elemento; nenhuma comparação foi necessária.";
    row.appendChild(cell);
    stepsBody.appendChild(row);
    return;
  }

  steps.forEach((step, index) => {
    const row = document.createElement("tr");
    const cells = [
      String(index + 1),
      step.comparison,
      step.decision,
      formatArray(step.state)
    ];

    cells.forEach((value, cellIndex) => {
      const cell = document.createElement("td");
      cell.textContent = value;
      if (cellIndex === 2) {
        cell.className = step.swapped ? "swap" : "no-swap";
      }
      row.appendChild(cell);
    });
    stepsBody.appendChild(row);
  });
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  message.textContent = "";
  message.className = "message";

  const parsed = parseNumbers(numbersInput.value);
  if (parsed.error) {
    resultsSection.hidden = true;
    stepsSection.hidden = true;
    message.textContent = parsed.error;
    message.classList.add("error");
    return;
  }

  const original = parsed.numbers;
  const order = orderInput.value;
  const algorithm = algorithmInput.value;
  const result = algorithm === "bubble"
    ? bubbleSort(original, order)
    : selectionSort(original, order);

  renderNumberList(originalResult, original);
  renderNumberList(sortedResult, result.values);
  comparisonsCount.textContent = String(result.comparisons);
  swapsCount.textContent = String(result.swaps);
  algorithmName.textContent = algorithm === "bubble" ? "Bubble Sort" : "Selection Sort";
  renderSteps(result.steps);

  resultsSection.hidden = false;
  stepsSection.hidden = false;
  message.textContent = "Ordenação concluída com sucesso!";
  message.classList.add("success");
});

document.querySelector("#example-button").addEventListener("click", () => {
  numbersInput.value = "5, 2, 8, 1";
  message.textContent = "Exemplo preenchido. Clique em “Ordenar números”.";
  message.className = "message success";
  numbersInput.focus();
});

document.querySelector("#clear-button").addEventListener("click", () => {
  numbersInput.value = "";
  message.textContent = "";
  message.className = "message";
  resultsSection.hidden = true;
  stepsSection.hidden = true;
  numbersInput.focus();
});

// Esta função é usada somente para conferir os resultados dos testes.
// Array.sort() não é usado na implementação dos algoritmos principais.
function expectedResult(input, order) {
  return [...input].sort((a, b) => order === "asc" ? a - b : b - a);
}

function runAlgorithmTests(sortFunction) {
  const tests = [
    { name: "Sequência comum", input: "5, 2, 8, 1", expected: [1, 2, 5, 8], order: "asc" },
    { name: "Valores repetidos", input: "4, 2, 4, 1", expected: [1, 2, 4, 4], order: "asc" },
    { name: "Valores negativos", input: "3, -5, 0, -1", expected: [-5, -1, 0, 3], order: "asc" },
    { name: "Um elemento", input: "7", expected: [7], order: "asc" },
    { name: "Sequência vazia", input: "", expected: null, order: "asc", invalid: true },
    { name: "Entrada inválida", input: "3, abc, 2", expected: null, order: "asc", invalid: true },
    { name: "Ordem decrescente", input: "1, 5, 3", expected: [5, 3, 1], order: "desc" }
  ];

  return tests.map((test) => {
    const parsed = parseNumbers(test.input);
    if (test.invalid) {
      return { name: test.name, passed: Boolean(parsed.error) };
    }
    if (parsed.error) return { name: test.name, passed: false };

    const actual = sortFunction(parsed.numbers, test.order).values;
    const expected = expectedResult(test.expected === null ? parsed.numbers : test.expected, test.order);
    const target = test.order === "asc" ? test.expected : test.expected;
    const matchesTarget = actual.length === target.length &&
      actual.every((value, index) => value === target[index]);
    const matchesReference = actual.length === expected.length &&
      actual.every((value, index) => value === expected[index]);

    return { name: test.name, passed: matchesTarget && matchesReference };
  });
}

document.querySelector("#run-tests").addEventListener("click", () => {
  const bubbleResults = runAlgorithmTests(bubbleSort);
  const selectionResults = runAlgorithmTests(selectionSort);
  testsBody.replaceChildren();

  let totalPassed = 0;
  const allResults = bubbleResults.map((bubble, index) => {
    const selection = selectionResults[index];
    if (bubble.passed) totalPassed++;
    if (selection.passed) totalPassed++;
    return { name: bubble.name, bubble: bubble.passed, selection: selection.passed };
  });

  allResults.forEach((result) => {
    const row = document.createElement("tr");
    const nameCell = document.createElement("td");
    nameCell.textContent = result.name;
    row.appendChild(nameCell);

    for (const passed of [result.bubble, result.selection]) {
      const cell = document.createElement("td");
      cell.textContent = passed ? "✓ Aprovado" : "✗ Falhou";
      cell.className = passed ? "test-ok" : "test-fail";
      row.appendChild(cell);
    }
    testsBody.appendChild(row);
  });

  const total = bubbleResults.length + selectionResults.length;
  const success = totalPassed === total;
  testSummary.textContent = `${totalPassed} de ${total} verificações aprovadas (${bubbleResults.length} cenários por algoritmo).`;
  testSummary.className = `test-summary ${success ? "pass" : "fail"}`;
});
