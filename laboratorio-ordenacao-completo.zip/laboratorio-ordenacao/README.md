# Laboratório de Ordenação

## 1. Sobre o projeto
O Laboratório de Ordenação é uma aplicação web educativa desenvolvida para a disciplina de Estrutura de Dados do Curso Técnico em Informática. O objetivo é demonstrar como algoritmos de ordenação comparam e reorganizam números.

## 2. Funcionalidades
- Recebe números separados por vírgulas ou espaços.
- Valida entradas vazias e valores não numéricos.
- Permite ordenar em ordem crescente ou decrescente.
- Permite selecionar Bubble Sort ou Selection Sort.
- Mostra a sequência original e a sequência ordenada.
- Registra comparações, trocas e o estado do vetor em cada etapa.
- Aceita números negativos, repetidos e sequências com um elemento.
- Inclui uma bateria de sete cenários de teste para os dois algoritmos.
- Interface responsiva para computadores e celulares.

## 3. Tecnologias
- HTML5 para a estrutura semântica.
- CSS3 para o estilo e a responsividade.
- JavaScript puro para validação, algoritmos e interação.
- Git e GitHub para versionamento.
- GitHub Pages para publicação estática (quando configurado).

## 4. Algoritmos implementados
### Bubble Sort
Compara elementos vizinhos. Se estiverem na ordem incorreta, troca suas posições. O processo continua até que uma passagem seja concluída sem trocas ou que todos os elementos estejam ordenados.

### Selection Sort
Percorre a parte ainda não ordenada para encontrar o menor elemento (ordem crescente) ou o maior (ordem decrescente). Depois, troca esse elemento com o primeiro da parte não ordenada.

Os dois algoritmos são implementados manualmente em `script.js`. `Array.sort()` aparece somente na função separada `expectedResult`, utilizada como referência nos testes automatizados.

## 5. Como executar localmente
1. Baixe ou clone este repositório.
2. Mantenha `index.html`, `style.css`, `script.js` e `README.md` na mesma pasta.
3. Abra `index.html` em um navegador moderno.
4. Digite números, selecione algoritmo e sentido, e clique em **Ordenar números**.
5. Para conferir os testes, clique em **Executar os 7 testes**.

Não é necessário instalar dependências nem configurar um servidor.

## 6. Exemplos
| Entrada | Algoritmo | Ordem | Resultado |
|---|---|---|---|
| `5, 2, 8, 1` | Bubble Sort | Crescente | `1, 2, 5, 8` |
| `4 2 4 1` | Selection Sort | Crescente | `1, 2, 4, 4` |
| `3, -5, 0, -1` | Bubble Sort | Crescente | `-5, -1, 0, 3` |
| `1, 5, 3` | Selection Sort | Decrescente | `5, 3, 1` |
| *(vazio)* | Qualquer | — | Mensagem para informar números |
| `3, abc, 2` | Qualquer | — | Mensagem de entrada inválida |

## 7. Testes
A página inclui os sete cenários solicitados: sequência comum, valores repetidos, valores negativos, um elemento, sequência vazia, entrada inválida e ordenação decrescente. A bateria executa cada cenário nos dois algoritmos.

## 8. Estrutura dos arquivos
- `index.html`: conteúdo e estrutura da interface.
- `style.css`: cores, layout e adaptação para telas menores.
- `script.js`: validação, Bubble Sort, Selection Sort, histórico de passos e testes.
- `README.md`: documentação do projeto.

## 9. Publicação no GitHub Pages
1. Crie um repositório no GitHub.
2. Envie os quatro arquivos para a raiz do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/(root)` e salve.
6. Aguarde a publicação e abra o endereço indicado pelo GitHub Pages.
7. Teste a página e acrescente os endereços reais do repositório e do site nesta documentação.

**Repositório:** *(adicionar o endereço real)*  
**Site publicado:** *(adicionar o endereço real)*

## 10. Limitações e melhorias futuras
O projeto trabalha com números representáveis pelo JavaScript e mostra o histórico das comparações em uma tabela. Como melhorias futuras, pode-se adicionar animações, controles para avançar passo a passo, medir o tempo de execução e incluir outros algoritmos.

## 11. Autores e créditos
**Autores:** *(preencher com os nomes dos integrantes do grupo)*  
**Disciplina:** Estrutura de Dados  
**Curso:** Técnico em Informática  
**Instituição:** *(preencher)*  
**Professor(a):** *(preencher)*

Projeto desenvolvido para fins educacionais. Personalize esta seção para refletir a contribuição real de cada integrante.
